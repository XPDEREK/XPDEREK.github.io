import time
#This is a comment
def Johnny Johnny():
    print("dad walks in the kitchen and sees Johnny on the floor")
    time.sleep(3)
    print('  _____              _ _     _    _')                  
    print(' |  __ \            ( ) |   | |  (_)   ')               
    print(' | |  | | ___  _ __ |/| |_  | | ___ ___ ___      ')     
    print(' | |  | |/ _ \| _ \ | __| | |/ / / __/ __|     ')     
    print(' | |__| | (_) | | | | | |_  |   <| \__ \__ \     ')     
    print(' |_____/ \___/|_| |_|  \__| |_|\_\_|___/___/      ')    
    print('                           / ____(_)   | |         ')   
    print('  _   _  ___  _   _ _ __  | (___  _ ___| |_ ___ _ __ ') 
    print(' | | | |/ _ \| | | | __|  \___ \| / __| __/ _ \ __|') 
    print(' | |_| | (_) | |_| | |     ____) | \__ \ ||  __/ |   ') 
    print('  \__. |\___/ \__._|_|    |_____/|_|___/\__\___|_|   ') 
    print('   __/ |                                           ')   
    print('  |___/ ') 
    time.sleep(2)
    print("dad calls your name" 'Johnny Johnny')
    time.sleep(1)
    print('You hear him and you respond' 'Yes papa?')
    time.sleep(1)
    choice=raw_input('eating sugar? (yes papa /no papa)')
    while choice == 'Y':
        print('Bad boy, time out nOw!')
        time.sleep(1)
        print('dad puts you in the corner and spanks you and gets a false report of child abuse')
        time.sleep(1)
        print('You do not have a dad anymore since he is in jail and you get put up for foster care')
        time.sleep(1)
        return
    choice=raw_input('Telling lies?(Yes papa/No papa)')
    while choice != 'no papa' and choice !='Yes papa':
        choice=raw_input('Invalid Answer. Try again(Yes papa/No papa)')
    if choice == 'Yes papa':
        print('(cough cough) Son, I despise liars and I dont like having you anymore')
        time.sleep(1)
        print('Spanking is not a good punishment for this')
        time.sleep(1)
        print('I am sorry, but I am going to put you up for adoption for the Lie you made')
        return
    else: #No papa
        choice=raw_input('Open your mouth ( decides not to/complies with request)')
        while choice != 'decides not to' and choice != 'complies with request':
            choice=raw_input('Invalid Answer.Try again. (decides not to/complies with request)')
        if choice == 'decides not to':
            print('So you are eating sugar!')
            time.sleep(1)
            print('AnD yOu WeRe LyInG about not eating sugar')
            time.sleep(1)
            print('You know how much this hurts me son?')
            time.sleep(1)
            print('You will starve till I say it is time to eat!')
            time.sleep(1)
            print('he did not feed you for a while so you end up being very skinny, but he did not feed you. A complete stranger fed you and as he feeds you, you see your dad getting arrested for child endangerment and child abuse.)
            print('you get put up for adoption and cannot see your father ever again.')
            return
        else: #complies with request
            print('Harrison Ford drives the Millenial Falcon to the Deaf Star.')
        time.sleep(3)
        print('You open your mouth to your dad......')
        time.sleep(2)
            print('But the window was open so people could look in on what is happening......')
            time.sleep(2)
        print('Cops come in and dad gets arrested for pedophilia, but with no harm was done to you.')
        time.sleep(1)
        print('You got older and decide to forget your father and go live with your mom and now a step dad.')